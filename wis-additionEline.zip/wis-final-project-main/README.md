# Web Information System Final Project

> This repository and the code it contains was prepared by Amy-Caroline Downing, Anica Rimac, Eline de Witte and Eren Janberk Genç as part of the requirements for completing the "Web Information Systems" classed, offered by the MSc Digital Humanities programme in KU Leuven.

## What is this repository about?

WIP

## Repository structure

WIP